<?php

$url = "https://www3.nhk.or.jp/news/html/20200729/k10012538361000.html";
function getPageTitle($url) {
     static $regex = '@<title>([^<]++)</title>@i';
     static $order = 'ASCII,JIS,UTF-8,CP51932,SJIS-win';
     static $ch;
     if (!$ch) {
     $ch = curl_init();
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
     }
     curl_setopt($ch, CURLOPT_URL, $url);
     $html = mb_convert_encoding(curl_exec($ch), 'UTF-8', $order);
     return preg_match($regex, $html, $m) ? $m[1] : '';
    }


?>
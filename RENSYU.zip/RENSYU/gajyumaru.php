<?php
    //まずはデータベースへ接続します
    $dsn = "mysql:dbname=php_tools;host=localhost;charset=utf8mb4";
    $username = "root";
    $password = "root";
    $options = [];
    $pdo = new PDO($dsn, $username, $password, $options);
    //追加ボタンが押された時の処理を記述します。
    if (null !== $_POST["create"]) { //追加ボタンが押され方どうかを確認
        if($_POST["title"] != "" OR $_POST["contents"] != ""){ //メモが入力されているかを確認
            //メモの内容を追加するSQL文を作成し、executeで実行します。
            $stmt = $pdo->prepare("INSERT INTO gajyumaru(title,contents) VALUE (:title,:contents)"); //SQL文の骨子を準備
            $stmt->bindvalue(":title", $_POST["title"]); //:titleをpost送信されたtitleの内容に置換
            $stmt->bindvalue(":contents", $_POST["contents"]); //:contentsをpost送信されたcontentsの内容に置換
            $stmt->execute(); //SQL文を実行
        }
    }
      //変更ボタンが押された時の処理を記述します。
      if (null !== $_POST["update"]) { //変更ボタンが押され方どうかを確認
        $stmt = $pdo->prepare("UPDATE gajyumaru SET title=:title, contents=:contents WHERE ID=:id");
        $stmt->bindvalue(":title", $_POST["title"]);
        $stmt->bindvalue(":contents", $_POST["contents"]);
        $stmt->bindvalue(":id", $_POST["id"]);
        $stmt->execute();
    }
    //削除ボタンが押された時の処理を記述します。
    if (null !== $_POST["delete"]) { //削除ボタンが押され方どうかを確認
        $stmt = $pdo->prepare("DELETE FROM gajyumaru WHERE ID=:id");
        $stmt->bindvalue(":id", $_POST["id"]);
        $stmt->execute();
    }
?>
      <!DOCTYPE html>
      <html lang="ja">
      <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>apuri機能</title>
          <link rel="stylesheet" href="./gajyumaru.css">
      </head>
      <body>
      <!-- Particle -->
        <div class="container">
            <div class="box">
                <h1>particles.js Demo</h1>
                <p><a href="https://marcbruederlin.github.io/particles.js/">Website</a></p>
            </div>
        </div>
        <canvas class="background"></canvas>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/particlesjs/2.2.2/particles.min.js"></script>
                  <!-- メモの新規作成フォーム -->
        <form class="basic_form flex" action="gajyumaru.php" method="post">
            <p>create</p>
            <br>
                  Title<br>
            <input type="text" name="title" size="20"></input><br>
            Contents<br>
            <textarea name="contents" style="width:300px; height:100px;"></textarea><br>
            <input type="submit" name="create" value="submit">
        </form>
        <!-- 以下にメモ一覧を追加 -->
        <p class="memo"> all</p>
        <?php
            //gajyumaruテーブルからデータを取得
            $stmt = $pdo->query("SELECT * FROM gajyumaru");
            //foreachを使ってデータを１つずつ順番に処理していく
            foreach ($stmt as $row):
        ?>
            <form class="made_form" action="gajyumaru.php" method="post">
                <input type="hidden" name="id" value="<?php echo $row[0]?>"></input>
                Title<br>
                <input type="text" name="title" size="20" value="<?php echo $row[1]?>"></input><br>
                Contents<br>
                <textarea name="contents" style="width:300px; height:100px;"><?php echo $row[2]?></textarea><br>
                <input type="submit" name="update" value="update">
                <input type="submit" name="delete" value="delete">
            </form>
        <?php endforeach; ?>

      </body>
      </html>  
        
        
   
